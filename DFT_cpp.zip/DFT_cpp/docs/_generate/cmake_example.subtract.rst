﻿cmake\_example.subtract
=======================

.. currentmodule:: cmake_example

.. autofunction:: subtract