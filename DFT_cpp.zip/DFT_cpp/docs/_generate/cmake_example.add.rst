﻿cmake\_example.add
==================

.. currentmodule:: cmake_example

.. autofunction:: add